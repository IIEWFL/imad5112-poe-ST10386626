package com.example.st10386626_calculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class StatsActivity : AppCompatActivity() {

    private lateinit var userInput: EditText
    private lateinit var addNumber: Button
    private lateinit var averageNumber: Button
    private lateinit var averageOutput: TextView
    private lateinit var userOutput: TextView
    private lateinit var minMax: Button
    private lateinit var minMaxOutput: TextView
    private lateinit var clearField: Button

    private val numberArray = Array(10) { 0 }
    private var counter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        val homeButton = findViewById<Button>(R.id.homeButton)

        homeButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        userInput = findViewById(R.id.userInput)
        addNumber = findViewById(R.id.addNumber)
        averageNumber = findViewById(R.id.averageNumber)
        averageOutput = findViewById(R.id.averageOutput)
        userOutput = findViewById(R.id.userOutput)
        minMax = findViewById(R.id.minMax)
        minMaxOutput = findViewById(R.id.minMaxOutput)
        clearField = findViewById(R.id.clearField)

        addNumber.setOnClickListener {
            val userInputNumber = userInput.text.toString()

            if (counter < numberArray.size) {
                if (userInputNumber.isNotEmpty()) {
                    numberArray[counter] = userInputNumber.toInt()
                    counter++
                    userInput.text.clear()
                    userOutput.append("$userInputNumber, ")
                } else {
                    averageOutput.text = "Please enter a valid number."
                }
            } else {
                averageOutput.text = "Array is full. Cannot store more values."
            }
        }

        averageNumber.setOnClickListener {
            var sum = 0.0

            var count = 0

            for (num in numberArray) {
                if (num != 0) {
                    sum += num
                    count++
                }
            }
            if (count > 0) {
                val average = sum / count
                averageOutput.text = "Average is $average"
            } else {
                averageOutput.text = "Please enter at least one number."
            }
        }

        minMax.setOnClickListener {
            if (counter > 0) {

                val validNumbers = numberArray.filter { it != 0 }

                if (validNumbers.isNotEmpty()) {
                    val minValue = validNumbers.minOrNull()
                    val maxValue = validNumbers.maxOrNull()

                    minMaxOutput.text = "Minimum: $minValue\nMaximum: $maxValue"
                } else {
                    minMaxOutput.text = "Please enter at least one non-zero number."
                }
            } else {
                minMaxOutput.text = "Please enter at least one number."
            }
        }

            clearField.setOnClickListener {

                for (i in numberArray.indices) {
                    numberArray[i] = 0
                }

                counter = 0

                userInput.text.clear()
                minMaxOutput.text = ""
                averageOutput.text = ""
                userOutput.text = ""
            }

        }
    }